from algorithm import stock
from algorithm import fitting
from .stock import Stock
from .fitting import *
