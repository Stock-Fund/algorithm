from algorithm import stock
from algorithm import fitting
from algorithm.fitting import *
from algorithm.stock import *
