from algorithm.fitting import *
from algorithm.stock import *
