from algorithm import stock
from algorithm import fitting
from .fitting import *
