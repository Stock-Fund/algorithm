from algorithm.fitting import *
from algorithm.stock import *
from algorithm.box_logic import *
from algorithm.ma_logic import *
from algorithm.volum_logic import *
from algorithm.predict_logic import *
from algorithm.turnoverRates_logic import * 
