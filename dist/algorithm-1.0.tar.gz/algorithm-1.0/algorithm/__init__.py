from algorithm import fitting,stock
